
enum IntervalState {
    clear = 0,
    work = 1,
    didWork = 2,
    didNotWork = 3,
    cursor = 4,
}

interface CalenderDay {
    date: Date,
    intervals: IntervalState[]
}

const getIntervalStateClass = (intState: IntervalState) => {
    switch(intState) {
        case IntervalState.clear: return 'clear';
        case IntervalState.work: return 'work';
        case IntervalState.didWork: return 'didWork';
        case IntervalState.didNotWork: return 'didNotWork';
        case IntervalState.cursor: return 'cursor';
        default: return 'clear';
    }
}

const makeIntervalHeaders = (days: CalenderDay[]) => {
    let headerRow = '<tr>';
    for(let j in days) {
        const day = days[j].date.toLocaleDateString().slice(0, -5);

        headerRow += /*html*/`
        <th class="calenderheader">
            ${day}
        </th>`;
    }
    headerRow += '</tr>';
}

const makeIntervalColumn = (days: CalenderDay[], interval: number) => {
    let column = '';
    for(let i = 0; i < days.length; i++) {
        column += /*html*/`
            <td class="calender${getIntervalStateClass(days[i].intervals[interval])}">
                ${days[i].intervals[interval]}
            </td>
        `;
    }
    return column;
}

const makeIntervalRows = (days: CalenderDay[]) => {
    let rows = '';
    for(let i = 0; i < days[0].intervals.length; i++) {
        rows += '<tr>';
        rows += makeIntervalColumn(days, i);
        rows += '</tr>';
    }
    return rows;
}

const makeIntervals = (days: CalenderDay[]) => {
    let intervals = '';
    intervals += makeIntervalHeaders(days);
    intervals += makeIntervalRows(days);
    return intervals;
}

const htmlCalender = (intervals: string) => /*html*/`
    <div id="calender">
        <table>${intervals}</table>
    </div>
`;

export const loadCalender = () => {

    const days: CalenderDay[] = [
        {date: new Date(Date.now() - 1000*60*60*24*1), intervals: [0, 2, 2, 2, 2, 2, 2, 0]},
        {date: new Date(Date.now()), intervals: [2, 2, 2, 4, 1, 1, 0, 0]},
        {date: new Date(Date.now() + 1000*60*60*24*1), intervals: [0, 1, 1, 1, 0, 0, 0, 0]},
        {date: new Date(Date.now() + 1000*60*60*24*2), intervals: [0, 0, 0, 1, 1, 1, 0, 0]},
        {date: new Date(Date.now() + 1000*60*60*24*3), intervals: [0, 0, 0, 0, 0, 0, 0, 0]},
        {date: new Date(Date.now() + 1000*60*60*24*4), intervals: [0, 0, 0, 0, 0, 0, 0, 0]},
        {date: new Date(Date.now() + 1000*60*60*24*5), intervals: [0, 0, 0, 0, 0, 0, 0, 0]}
    ];

    const intervals = makeIntervals(days);
    const html = htmlCalender(intervals);


    return html;
}
